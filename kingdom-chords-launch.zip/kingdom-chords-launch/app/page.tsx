"use client";

import React, { useMemo, useState } from "react";
import { Crown, Guitar, Mic, Music2, Radio, CreditCard, Sparkles } from "lucide-react";

const openChords: Record<string, string[]> = {
  G: ["3", "2", "0", "0", "0", "3"],
  C: ["x", "3", "2", "0", "1", "0"],
  D: ["x", "x", "0", "2", "3", "2"],
  A: ["x", "0", "2", "2", "2", "0"],
  E: ["0", "2", "2", "1", "0", "0"],
  Em: ["0", "2", "2", "0", "0", "0"],
  Am: ["x", "0", "2", "2", "1", "0"],
  F: ["1", "3", "3", "2", "1", "1"],
};

function ChordChart({ chord }: { chord: string }) {
  const fingering = openChords[chord] || openChords.G;
  return (
    <div className="rounded-3xl bg-white p-5 shadow">
      <div className="mb-4 text-center text-3xl font-black text-violet-900">{chord} chord</div>
      <div className="grid grid-cols-6 gap-2">
        {fingering.map((fret, i) => (
          <div key={i} className="flex flex-col items-center gap-2">
            <div className="text-sm font-bold text-slate-500">{fret}</div>
            <div className="h-40 w-1 rounded bg-slate-300 relative">
              {fret !== "0" && fret !== "x" && (
                <div className="absolute left-1/2 top-12 h-6 w-6 -translate-x-1/2 rounded-full bg-violet-700 shadow" />
              )}
            </div>
            <div className="text-xs text-slate-500">S{i + 1}</div>
          </div>
        ))}
      </div>
      <p className="mt-4 text-center text-sm text-slate-500">x = do not play. 0 = open string.</p>
    </div>
  );
}

export default function KingdomChordsPage() {
  const [selectedChord, setSelectedChord] = useState("G");
  const [songLoaded, setSongLoaded] = useState(false);
  const [currentChord, setCurrentChord] = useState("G");
  const [message, setMessage] = useState("");

  const progression = useMemo(() => ["G", "D", "Em", "C", "G", "D", "C"], []);

  async function startCheckout() {
    setMessage("Opening secure checkout...");
    const response = await fetch("/api/create-checkout-session", { method: "POST" });
    const data = await response.json();
    if (data.url) {
      window.location.href = data.url;
    } else {
      setMessage(data.error || "Checkout is not configured yet.");
    }
  }

  function demoAnalyze() {
    setSongLoaded(true);
    setCurrentChord("G");
    setMessage("Demo progression loaded. Full audio detection is the next production upgrade.");
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-violet-50 to-amber-50 p-4 md:p-8">
      <section className="mx-auto max-w-7xl space-y-8">
        <div className="rounded-[2rem] border border-violet-100 bg-white p-6 shadow-2xl">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-amber-800">
                <Crown className="h-4 w-4" /> Kingdom Chords
              </div>
              <h1 className="text-4xl font-black tracking-tight text-violet-950 md:text-6xl">
                Hear it. Play it. Live it.
              </h1>
              <p className="mt-4 max-w-2xl text-lg text-slate-600">
                A fast guitar-learning app with chord detection, live listening, guitar tuner, voice key trainer, and beginner chord charts.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button onClick={demoAnalyze} className="rounded-2xl bg-violet-700 px-6 py-3 font-bold text-white shadow hover:bg-violet-800">
                  Try demo
                </button>
                <button onClick={startCheckout} className="rounded-2xl bg-amber-500 px-6 py-3 font-bold text-white shadow hover:bg-amber-600">
                  Go Pro $9.99/mo
                </button>
              </div>
              {message && <p className="mt-3 text-sm font-semibold text-violet-800">{message}</p>}
            </div>
            <div className="rounded-[2rem] bg-violet-950 p-6 text-white shadow-xl">
              <div className="text-sm uppercase tracking-[0.24em] text-violet-200">Pro includes</div>
              <ul className="mt-4 space-y-2 text-sm">
                <li>Unlimited song scans</li>
                <li>Live chord mode</li>
                <li>Guitar tuner</li>
                <li>Voice key trainer</li>
                <li>Beginner chord charts</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-[2rem] bg-white p-6 shadow-xl">
            <div className="flex items-center gap-2 text-2xl font-black text-violet-950">
              <Music2 className="h-6 w-6" /> Chord finder
            </div>
            <div className="mt-5 rounded-3xl border border-dashed border-violet-200 bg-violet-50 p-5">
              <label className="text-sm font-bold text-slate-700">Upload song</label>
              <input type="file" accept="audio/*" className="mt-2 block w-full rounded-xl bg-white p-3" onChange={() => setMessage("File loaded. Click demo to preview launch UI.")} />
              <button onClick={demoAnalyze} className="mt-4 rounded-2xl bg-violet-700 px-5 py-3 font-bold text-white">
                Analyze song
              </button>
            </div>

            <div className="mt-6 rounded-3xl bg-slate-950 p-6 text-white">
              <div className="text-sm uppercase tracking-[0.2em] text-slate-400">Current chord</div>
              <div className="mt-2 text-6xl font-black">{currentChord}</div>
              <div className="mt-2 text-sm text-slate-300">Next change: D</div>
            </div>

            <div className="mt-5 grid grid-cols-4 gap-2 md:grid-cols-7">
              {progression.map((chord, idx) => (
                <button
                  key={`${chord}-${idx}`}
                  onClick={() => {
                    setCurrentChord(chord);
                    setSelectedChord(chord);
                  }}
                  className="rounded-2xl bg-violet-50 p-4 text-xl font-black text-violet-900 hover:bg-amber-100"
                >
                  {chord}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <ChordChart chord={selectedChord} />

            <div className="grid gap-4 md:grid-cols-2">
              <Feature icon={<Radio />} title="Live mode" text="Listen through the mic and estimate chords." />
              <Feature icon={<Guitar />} title="Tuner" text="Tune guitar strings fast." />
              <Feature icon={<Mic />} title="Voice key" text="Help singers find and hit their key." />
              <Feature icon={<Sparkles />} title="Beginner mode" text="Simpler chords for new players." />
            </div>
          </div>
        </div>

        <div className="rounded-[2rem] bg-white p-6 shadow-xl">
          <div className="flex items-center gap-2 text-2xl font-black text-violet-950">
            <CreditCard className="h-6 w-6" /> Pricing
          </div>
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <div className="rounded-3xl bg-slate-50 p-6">
              <div className="text-sm font-bold uppercase tracking-[0.2em] text-slate-500">Free</div>
              <div className="mt-2 text-4xl font-black">$0</div>
              <p className="mt-3 text-slate-600">Tuner + limited scans.</p>
            </div>
            <div className="rounded-3xl bg-violet-950 p-6 text-white">
              <div className="text-sm font-bold uppercase tracking-[0.2em] text-violet-200">Pro</div>
              <div className="mt-2 text-4xl font-black">$9.99/mo</div>
              <p className="mt-3 text-violet-100">Unlimited scans, live mode, voice trainer, chord charts.</p>
              <button onClick={startCheckout} className="mt-5 rounded-2xl bg-amber-500 px-5 py-3 font-bold text-white">
                Start Pro
              </button>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function Feature({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-3xl bg-white p-5 shadow">
      <div className="text-violet-800">{icon}</div>
      <div className="mt-3 text-lg font-black text-violet-950">{title}</div>
      <p className="mt-1 text-sm text-slate-600">{text}</p>
    </div>
  );
}
