export default function CancelPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-violet-50 p-8 text-center">
      <div className="mx-auto max-w-xl rounded-3xl bg-white p-8 shadow-xl">
        <h1 className="text-4xl font-black text-violet-900">Checkout canceled</h1>
        <p className="mt-4 text-slate-600">No charge was made.</p>
        <a href="/" className="mt-6 inline-block rounded-2xl bg-violet-700 px-6 py-3 font-bold text-white">
          Return to Kingdom Chords
        </a>
      </div>
    </main>
  );
}
