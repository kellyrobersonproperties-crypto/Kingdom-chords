export default function SuccessPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white to-amber-50 p-8 text-center">
      <div className="mx-auto max-w-xl rounded-3xl bg-white p-8 shadow-xl">
        <h1 className="text-4xl font-black text-violet-900">Welcome to Kingdom Chords Pro</h1>
        <p className="mt-4 text-slate-600">Your subscription checkout was successful.</p>
        <a href="/" className="mt-6 inline-block rounded-2xl bg-violet-700 px-6 py-3 font-bold text-white">
          Go back to app
        </a>
      </div>
    </main>
  );
}
