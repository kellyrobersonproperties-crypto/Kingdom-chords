# Kingdom Chords Launch Build

This is a fast-launch Next.js web app for Kingdom Chords.

## What is included
- Landing page
- Chord detector prototype UI
- Live mode placeholder
- Guitar tuner placeholder
- Voice key trainer placeholder
- Chord chart section
- Stripe subscription checkout API route
- Success and cancel pages
- Environment variable template

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Stripe setup

Create a Stripe product:
- Product name: Kingdom Chords Pro
- Monthly price: $9.99/month

Then copy the Price ID into `.env.local`.

## Environment variables

Copy `.env.example` to `.env.local`:

```bash
cp .env.example .env.local
```

Then fill these in:

```bash
NEXT_PUBLIC_APP_URL=http://localhost:3000
STRIPE_SECRET_KEY=sk_test_your_key_here
STRIPE_PRICE_ID=price_your_price_id_here
```

For Vercel, add the same values in:
Project Settings → Environment Variables

## Deploy to Vercel

Push this folder to GitHub, then import the repo into Vercel.
